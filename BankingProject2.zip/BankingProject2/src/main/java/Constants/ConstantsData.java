package Constants;

public class ConstantsData {
	
	public final static String PropertyFilePath = "src/main/java/Constants/Global.properties";
	public final static String ExcelFilePath = "C:\\Users\\dasab\\Downloads\\TestDataUrl22ndApril.xlsx";
}
