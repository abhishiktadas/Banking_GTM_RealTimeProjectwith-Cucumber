package PageClass;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import Utilities.BaseClass;

public class AccountDetailsClass extends BaseClass {
	
	WebDriver driver;
	public AccountDetailsClass(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(xpath="(//a[@class='t-menu__link-item'])[7]")
	WebElement accountDetails;
	
	@FindBy(xpath="//select[@id='collection_comp-m8swuunx']")
	WebElement selectName;
	
	@FindBy(xpath="//button[contains(.,'Login')]")
	WebElement clickOnLogin;
	
	public void clickOnAccountDetails() {
		accountDetails.click();
	}
	
	public void selectName() throws AWTException {
		/*Select s1 = new Select(selectName);
		//s1.selectByVisibleText("Rahul");
		//s1.selectByIndex(1);
		s1.selectByContainsVisibleText("Rahul");
		s1.selectByIndex(1);*/
		//JavascriptExecutor js = (JavascriptExecutor) driver;

		//js.executeScript("arguments[0].value='highestprice'", selectName);
		
		
		Robot sw = new Robot();
		sw.keyPress(KeyEvent.VK_DOWN);
		sw.keyPress(KeyEvent.VK_ENTER);
		selectName.click();
		sw.keyPress(KeyEvent.VK_DOWN);
		sw.keyPress(KeyEvent.VK_DOWN);
		sw.keyPress(KeyEvent.VK_ENTER);
		
		
	}
	
	public void clickOnLoginButton() {
		clickOnLogin.click();
	}

}
